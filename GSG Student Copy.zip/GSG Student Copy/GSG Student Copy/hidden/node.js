function node(parent,x,y)
{
	this.parent=parent;
	this.x=x;
	this.y=y;
}