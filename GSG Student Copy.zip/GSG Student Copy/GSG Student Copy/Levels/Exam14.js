function Exam14(ListofLevels,floor,player,wall,enemy,endgoal,light) {var lvllayout14=[
[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,3,3,3,3,3,3,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0,0,5,0,0,0,0,0],

];
var ahhh14 = new map(lvllayout14,floor,player,wall,enemy,endgoal,light);
ListofLevels.push(ahhh14);



 var waypoint10267 = new Array();
 waypoint10267.push(new Point(2,3));
 waypoint10267.push(new Point(2,4));
 var enemy10267 = new ENEMY2(2,3,waypoint10267,lvllayout14,light,enemy);
 ahhh14.addEnemy(enemy10267);

 var waypoint10268 = new Array();
 waypoint10268.push(new Point(4,3));
 waypoint10268.push(new Point(4,4));
 var enemy10268 = new ENEMY2(4,3,waypoint10268,lvllayout14,light,enemy);
 ahhh14.addEnemy(enemy10268);

 var waypoint10269 = new Array();
 waypoint10269.push(new Point(6,3));
 waypoint10269.push(new Point(6,4));
 var enemy10269 = new ENEMY2(6,3,waypoint10269,lvllayout14,light,enemy);
 ahhh14.addEnemy(enemy10269);
 var waypoint10270 = new Array();
 waypoint10270.push(new Point(8,3));
 waypoint10270.push(new Point(8,4));
 var enemy10270 = new ENEMY2(8,3,waypoint10270,lvllayout14,light,enemy);
 ahhh14.addEnemy(enemy10270);

 var waypoint10271 = new Array();
 waypoint10271.push(new Point(10,3));
 waypoint10271.push(new Point(10,4));
 var enemy10271 = new ENEMY2(10,3,waypoint10271,lvllayout14,light,enemy);
 ahhh14.addEnemy(enemy10271);

 var waypoint10272 = new Array();
 waypoint10272.push(new Point(12,3));
 waypoint10272.push(new Point(12,4));
 var enemy10272 = new ENEMY2(12,3,waypoint10272,lvllayout14,light,enemy);
 ahhh14.addEnemy(enemy10272);

 var waypoint10273 = new Array();
 waypoint10273.push(new Point(14,3));
 waypoint10273.push(new Point(14,4));
 var enemy10273 = new ENEMY2(14,3,waypoint10273,lvllayout14,light,enemy);
 ahhh14.addEnemy(enemy10273);
 var waypoint10274 = new Array();
 waypoint10274.push(new Point(16,3));
 waypoint10274.push(new Point(16,4));
 var enemy10274 = new ENEMY2(16,3,waypoint10274,lvllayout14,light,enemy);
 ahhh14.addEnemy(enemy10274);

 var waypoint10275 = new Array();
 waypoint10275.push(new Point(17,3));
 waypoint10275.push(new Point(17,4));
 var enemy10275 = new ENEMY2(17,3,waypoint10275,lvllayout14,light,enemy);
 ahhh14.addEnemy(enemy10275);
 var waypoint10276 = new Array();
 waypoint10276.push(new Point(2,7));
 waypoint10276.push(new Point(2,8));
 var enemy10276 = new ENEMY2(2,7,waypoint10276,lvllayout14,light,enemy);
 ahhh14.addEnemy(enemy10276);

 var waypoint10277 = new Array();
 waypoint10277.push(new Point(2,11));
 waypoint10277.push(new Point(2,12));
 var enemy10277 = new ENEMY2(2,11,waypoint10277,lvllayout14,light,enemy);
 ahhh14.addEnemy(enemy10277);
 var waypoint10278 = new Array();
 waypoint10278.push(new Point(2,15));
 waypoint10278.push(new Point(2,16));
 var enemy10278 = new ENEMY2(2,15,waypoint10278,lvllayout14,light,enemy);
 ahhh14.addEnemy(enemy10278);

 var waypoint10279 = new Array();
 waypoint10279.push(new Point(7,10));
 waypoint10279.push(new Point(7,11));
 var enemy10279 = new ENEMY2(7,10,waypoint10279,lvllayout14,light,enemy);
 ahhh14.addEnemy(enemy10279);

 var waypoint10280 = new Array();
 waypoint10280.push(new Point(9,10));
 waypoint10280.push(new Point(9,11));
 var enemy10280 = new ENEMY2(9,10,waypoint10280,lvllayout14,light,enemy);
 ahhh14.addEnemy(enemy10280);

 var waypoint10282 = new Array();
 waypoint10282.push(new Point(9,10));
 waypoint10282.push(new Point(9,11));
 var enemy10282 = new ENEMY2(9,10,waypoint10282,lvllayout14,light,enemy);
 ahhh14.addEnemy(enemy10282);
 var waypoint10283 = new Array();
 waypoint10283.push(new Point(11,10));
 waypoint10283.push(new Point(11,11));
 var enemy10283 = new ENEMY2(11,10,waypoint10283,lvllayout14,light,enemy);
 ahhh14.addEnemy(enemy10283);
 var waypoint10284 = new Array();
 waypoint10284.push(new Point(13,10));
 waypoint10284.push(new Point(13,11));
 var enemy10284 = new ENEMY2(13,10,waypoint10284,lvllayout14,light,enemy);
 ahhh14.addEnemy(enemy10284);
 var waypoint10285 = new Array();
 waypoint10285.push(new Point(15,10));
 waypoint10285.push(new Point(15,11));
 var enemy10285 = new ENEMY2(15,10,waypoint10285,lvllayout14,light,enemy);
 ahhh14.addEnemy(enemy10285);
 var waypoint10286 = new Array();
 waypoint10286.push(new Point(17,10));
 waypoint10286.push(new Point(17,11));
 var enemy10286 = new ENEMY2(17,10,waypoint10286,lvllayout14,light,enemy);
 ahhh14.addEnemy(enemy10286);
 var waypoint10287 = new Array();
 waypoint10287.push(new Point(19,10));
 waypoint10287.push(new Point(19,11));
 var enemy10287 = new ENEMY2(19,10,waypoint10287,lvllayout14,light,enemy);
 ahhh14.addEnemy(enemy10287);
 var waypoint10288 = new Array();
 waypoint10288.push(new Point(18,17));
 waypoint10288.push(new Point(18,18));
 var enemy10288 = new ENEMY2(18,17,waypoint10288,lvllayout14,light,enemy);
 ahhh14.addEnemy(enemy10288);
 var waypoint10289 = new Array();
 waypoint10289.push(new Point(16,17));
 waypoint10289.push(new Point(16,18));
 var enemy10289 = new ENEMY2(16,17,waypoint10289,lvllayout14,light,enemy);
 ahhh14.addEnemy(enemy10289);
 var waypoint10290 = new Array();
 waypoint10290.push(new Point(14,17));
 waypoint10290.push(new Point(14,18));
 var enemy10290 = new ENEMY2(14,17,waypoint10290,lvllayout14,light,enemy);
 ahhh14.addEnemy(enemy10290);
 var waypoint10291 = new Array();
 waypoint10291.push(new Point(12,17));
 waypoint10291.push(new Point(12,18));
 var enemy10291 = new ENEMY2(12,17,waypoint10291,lvllayout14,light,enemy);
 ahhh14.addEnemy(enemy10291);
 var waypoint10292 = new Array();
 waypoint10292.push(new Point(10,17));
 waypoint10292.push(new Point(10,18));
 var enemy10292 = new ENEMY2(10,17,waypoint10292,lvllayout14,light,enemy);
 ahhh14.addEnemy(enemy10292);
 var waypoint10293 = new Array();
 waypoint10293.push(new Point(8,17));
 waypoint10293.push(new Point(8,18));
 var enemy10293 = new ENEMY2(8,17,waypoint10293,lvllayout14,light,enemy);
 ahhh14.addEnemy(enemy10293);
 var waypoint10294 = new Array();
 waypoint10294.push(new Point(6,17));
 waypoint10294.push(new Point(6,18));
 var enemy10294 = new ENEMY2(6,17,waypoint10294,lvllayout14,light,enemy);
 ahhh14.addEnemy(enemy10294);
 var waypoint10295 = new Array();
 waypoint10295.push(new Point(4,17));
 waypoint10295.push(new Point(4,18));
 var enemy10295 = new ENEMY2(4,17,waypoint10295,lvllayout14,light,enemy);
 ahhh14.addEnemy(enemy10295);
 var waypoint10296 = new Array();
 waypoint10296.push(new Point(2,17));
 waypoint10296.push(new Point(2,18));
 var enemy10296 = new ENEMY2(2,17,waypoint10296,lvllayout14,light,enemy);
 ahhh14.addEnemy(enemy10296);
}