var resourceList = [
	{name:"dgdl",url:"splashloader/dgdl.jpg", type:"ui"},
	

];